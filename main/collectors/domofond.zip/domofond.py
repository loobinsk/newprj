#-*- coding: utf-8 -*-
from lxml import html, etree
from lxml.html.soupparser import fromstring
from lxml.html import tostring
import requests
import re
from datetime import datetime
import time
import traceback
from main.collectors.base import Collector
from main.models import Town, Advert, UserImage, Blacklist, clear_tel, clear_tel_list, get_tel_list, Abbr, Parser
from uprofile.models import User
import logging
from django.utils.html import strip_tags
import random
import json
from django.core.cache import cache

logger = logging.getLogger('domofond')


class DomofondCollector(Collector):
    domain = 'https://www.domofond.ru/'

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
    }

    metro_list = None
    district_list = None
    town = None
    parser = None
    cached_ids = []

    def process_elements(self, doc, adtype, limit, need=Advert.NEED_SALE, set_moderate=True, level=Advert.CHECK_SPAM_LOW):
        element_list = doc.xpath('//div[contains(@class, "b-results-tile")]')
        need_wait = False
        for element in element_list:
            if need_wait:
                seconds = random.randrange(15, 30)
                logger.info('### ждем %s секунд ###' % seconds)
                time.sleep(seconds)
                need_wait = False

            item_link = element.xpath('.//a')
            if item_link:
                m = re.search(u'\-([0-9]+)$', item_link[0].get('href'))
                if m:
                    advert_id = m.group(1)
                    if not advert_id:
                        logger.info('Пустой код')
                        continue
                    if advert_id in self.cached_ids:
                        continue
                    txt = u'domofond_' + advert_id
                    logger.info(txt)
                    advert_list = Advert.objects.filter(extnum=txt)
                    if advert_list:
                        logger.info('Объявление есть в базе')
                        continue
                else:
                    logger.info('Код объявления не распознан')
                    continue

                r = requests.get(item_link[0].get('href'), cookies=self.cookies, allow_redirects=True, headers=self.headers)
                doc_advert = fromstring(r.text)
                doc_advert.make_links_absolute(self.domain)

                logger.info("=======================")
                logger.info(item_link[0].get('href'))
                need_wait = True

                self.cached_ids.append(advert_id)

                advert = Advert(town=self.town,
                                adtype = adtype,
                                need = need,
                                status=Advert.STATUS_MODERATE if set_moderate else Advert.STATUS_VIEW,
                                limit=limit,
                                user_id=1,
                                date=datetime.now(),
                                parser=self.parser,
                                extnum=u'domofond_' + advert_id)

                #заголовок
                nodes = doc_advert.xpath('.//h1')
                if nodes:
                    txt = nodes[0].text_content()
                    if u'квартира в аренду' in txt:
                        advert.estate = Advert.ESTATE_LIVE
                        advert.live = Advert.LIVE_FLAT
                        logger.info('нашли квартиру')
                    if u'комната в аренду' in txt:
                        advert.estate = Advert.ESTATE_LIVE
                        advert.live = Advert.LIVE_ROOM
                        logger.info('нашли комнату')

                    for room in xrange(1, 6):
                        if u'%s-комнат' % room in txt:
                            advert.rooms = room
                            if advert.rooms > 4:
                                advert.rooms = 4
                            if advert.rooms == 1:
                                advert.live_flat1 = True
                            elif advert.rooms == 2:
                                advert.live_flat2 = True
                            elif advert.rooms == 3:
                                advert.live_flat3 = True
                            elif advert.rooms >= 4:
                                advert.live_flat4 = True
                            logger.info('нашли %s комнат' % room)
                    if not advert.rooms:
                        advert.rooms = 1

                    # try:
                    #     m = re.search(u'([0-9|\.]+) м', txt)
                    #     if m:
                    #         advert.square = int(m.group(1))
                    #         logger.info('нашли площадь %s м' %advert.square)
                    # except Exception, err:
                    #     logger.info( traceback.format_exc())
                    #

                    # for floors in xrange(1, 50):
                    #     if (u'%s-этажного' % floors) in txt:
                    #         advert.count_floor = floors
                    #         logger.info('нашли этажи %s' % floors)

                # цена
                nodes = doc_advert.xpath('.//div[@itemprop="price"]')
                if nodes:
                    txt = strip_tags(html.tostring(nodes[0], encoding='unicode'))\
                        .replace(u'\u00A0', u'')\
                        .replace(u'&nbsp;', u'')
                    m = re.search(u'([0-9|\ ]+)РУБ', txt)
                    if m:
                        try:
                            advert.price = int(m.group(1)
                                               .replace(u' ', u'')
                                               .replace(u'\u00A0', u''))
                            logger.info('нашли цену %s' % advert.price)
                        except Exception, err:
                            logger.info( traceback.format_exc())

                if not advert.price and need == Advert.NEED_SALE:
                    logger.info('цена не найдена')
                    continue

                # проверка цены на ценовую политику
                if advert.town.slug == 'sankt-peterburg' and limit == Advert.LIMIT_LONG \
                        and need == Advert.NEED_SALE and adtype == Advert.TYPE_LEASE:
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_ROOM):
                        if advert.price < 8000:
                            logger.info('Не подходит: Комнаты от 8000 до (ограничения нет)')
                            continue
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_FLAT) and (advert.rooms == 1):
                        if advert.price < 17000:
                            logger.info('Не подходит: 1 ком.кв. от 17000 до (ограничения нет)')
                            continue
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_FLAT) and (advert.rooms == 2):
                        if advert.price < 19000:
                            logger.info('Не подходит: 2 ком.кв. от 19000 до (ограничения нет)')
                            continue
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_FLAT) and (advert.rooms == 3):
                        if advert.price < 20000:
                            logger.info('Не подходит: 3 ком.кв. от 20000 до (ограничения нет)')
                            continue
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_FLAT) and (advert.rooms >= 4):
                        if advert.price < 22000:
                            logger.info('Не подходит: 4 и более ком.кв. от 22000 до (ограничения нет)')
                            continue

                if advert.town.slug == 'moskva' and limit == Advert.LIMIT_LONG \
                        and need == Advert.NEED_SALE and adtype == Advert.TYPE_LEASE:
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_ROOM):
                        if advert.price < 10000 or advert.price > 50000:
                            logger.info('Не подходит: Комнаты от 10000 до 50000')
                            continue
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_FLAT) and (advert.rooms == 1):
                        if advert.price < 20000 or advert.price > 100000:
                            logger.info('Не подходит: 1 ком.кв. от 20000 до 100000')
                            continue
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_FLAT) and (advert.rooms == 2):
                        if advert.price < 25000 or advert.price > 100000:
                            logger.info('Не подходит: 2 ком.кв. от 250000 до 100000')
                            continue
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_FLAT) and (advert.rooms == 3):
                        if advert.price < 30000 or advert.price > 100000:
                            logger.info('Не подходит: 3 ком.кв. от 30000 до 100000')
                            continue
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_FLAT) and (advert.rooms >= 4):
                        if advert.price < 35000 or advert.price > 100000:
                            logger.info('Не подходит: 4 и более ком.кв. от 35000 до 100000')
                            continue

                if advert.town.slug == 'novosibirsk' and limit == Advert.LIMIT_LONG \
                        and need == Advert.NEED_SALE and adtype == Advert.TYPE_LEASE:
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_ROOM) and need == Advert.NEED_SALE:
                        if advert.price < 7000 or advert.price > 11000:
                            logger.info('Не подходит: Комнаты от 7000 до 11000')
                            continue
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_FLAT) and (advert.rooms == 1):
                        if advert.price < 15000 or advert.price > 21000:
                            logger.info('Не подходит: 1 ком.кв. от 15000 до 21000')
                            continue
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_FLAT) and (advert.rooms == 2):
                        if advert.price < 17000 or advert.price > 25000:
                            logger.info('Не подходит: 2 ком.кв. от 17000 до (25000')
                            continue
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_FLAT) and (advert.rooms == 3):
                        if advert.price < 17000 or advert.price > 33000:
                            logger.info('Не подходит: 3 ком.кв. от 17000 до 33000')
                            continue
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_FLAT) and (advert.rooms >= 4):
                        if advert.price < 18000 or advert.price > 35000:
                            logger.info('Не подходит: 4 и более ком.кв. от 18000 до 35000')
                            continue

                if advert.town.slug == 'ekaterinburg' and limit == Advert.LIMIT_LONG \
                        and need == Advert.NEED_SALE and adtype == Advert.TYPE_LEASE:
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_ROOM) and need == Advert.NEED_SALE:
                        if advert.price < 7000 or advert.price > 11000:
                            logger.info('Не подходит: Комнаты от 7000 до 11000')
                            continue
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_FLAT) and (advert.rooms == 1):
                        if advert.price < 9000 or advert.price > 21000:
                            logger.info('Не подходит: 1 ком.кв. от 9000 до 21000')
                            continue
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_FLAT) and (advert.rooms == 2):
                        if advert.price < 12000 or advert.price > 25000:
                            logger.info('Не подходит: 2 ком.кв. от 12000 до (25000')
                            continue
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_FLAT) and (advert.rooms == 3):
                        if advert.price < 17000 or advert.price > 33000:
                            logger.info('Не подходит: 3 ком.кв. от 17000 до 33000')
                            continue
                    if (advert.estate == Advert.ESTATE_LIVE) and (advert.live == Advert.LIVE_FLAT) and (advert.rooms >= 4):
                        if advert.price < 18000 or advert.price > 35000:
                            logger.info('Не подходит: 4 и более ком.кв. от 18000 до 35000')
                            continue

                # метро
                nodes = doc_advert.xpath('.//div[@class="m-closest-metro"]')
                if nodes:
                    txt = nodes[0].text_content()
                    for metro in self.metro_list:
                        if metro.title.lower() in txt.lower():
                            advert.metro = metro
                            logger.info('получено метро')
                            break

                # адрес
                nodes = doc_advert.xpath('.//div[@id="mapContainer"]/div[@class="row"]/div[@class="col-xs-12"]/p[1]')
                if nodes:
                    advert.address = nodes[0].text_content().strip()
                    logger.info('получен адрес')

                #координаты
                # nodes = doc_advert.xpath('.//div[@id="item-map"]')
                # if nodes:
                #     try:
                #         advert.latitude = float(nodes[0].get('data-coords-lat'))
                #         advert.longitude = float(nodes[0].get('data-coords-lng'))
                #         logger.info('получен координаты')
                #     except Exception, err:
                #         logger.info( traceback.format_exc())

                #имя владельца
                nodes = doc_advert.xpath('.//h6[@itemprop="name"]')
                if nodes:
                    advert.owner_name = nodes[0].text_content().strip()
                    logger.info('получено имя владельца')
                    if u'агент' in advert.owner_name.lower():
                        logger.info('это агент')
                        continue

                #описание
                nodes = doc_advert.xpath('.//p[@itemprop="description"]')
                if nodes:
                    advert.body = nodes[0].text_content().strip()
                    logger.info('получено описание')
                    advert.parse(advert.body)

                    if u'комисси' in advert.body.lower():
                        logger.info('есть комиссия')
                        continue

                # свойства
                nodes = doc_advert.xpath('//div[@class="b-details-table"]/div/ul/li')
                if nodes:
                    for node in nodes:
                        txt = node.text_content()\
                            .replace(u'\u00A0', u'')\
                            .replace(u'&nbsp;', u'')
                        if u'Этаж' in txt:
                            m = re.search(u'([0-9]+)\/([0-9]+)', txt)
                            if m:
                                try:
                                    advert.floor = int(m.group(1))
                                    logger.info('нашли этаж %s' % advert.floor)
                                except Exception, err:
                                    logger.info(traceback.format_exc())
                                try:
                                    advert.count_floor = int(m.group(2))
                                    logger.info('нашли количество этажей %s' % advert.count_floor)
                                except Exception, err:
                                    logger.info(traceback.format_exc())

                        if u'Площадь' in txt:
                            m = re.search(u'([0-9]+)m', txt)
                            if m:
                                try:
                                    advert.square = float(m.group(1))
                                    logger.info('нашли площадь %s' % advert.square)
                                except Exception, err:
                                    logger.info(traceback.format_exc())

                        if u'Холодильник' in txt:
                            advert.refrigerator = True
                        if u'Стиральная' in txt:
                            advert.washer = True
                        if u'балкон' in txt:
                            advert.balcony = True
                        if u'Стиральная машина' in txt:
                            advert.washer = True
                        if u'Wi-Fi' in txt:
                            advert.internet = True
                        if u'Телевизор' in txt:
                            advert.tv = True
                        if u'Кондиционер' in txt:
                            advert.conditioner = True


                #получение метро
                if not advert.metro and advert.latitude and advert.longitude:
                    try:
                        logger.info('запрос метро')
                        doc_text = self.download_url(u'http://geocode-maps.yandex.ru/1.x/?results=1&kind=metro&geocode=%s,%s' % (advert.longitude, advert.latitude), encoding='utf8')
                        doccoord = fromstring(doc_text)
                        metro_name = doccoord.xpath('//name')
                        if metro_name:
                            txt = metro_name[0].text_content()
                            for metro in self.metro_list:
                                if metro.title.lower() in txt.lower():
                                    advert.metro = metro
                                    logger.info('получено метро')
                                    break
                    except Exception, err:
                        logger.info( traceback.format_exc())

                #получение района
                if not advert.district and advert.latitude and advert.longitude:
                    try:
                        logger.info('запрос района')
                        doc_text = self.download_url(u'http://geocode-maps.yandex.ru/1.x/?results=1&kind=district&geocode=%s,%s' % (advert.longitude, advert.latitude), encoding='utf8')
                        doccoord = fromstring(doc_text)
                        district_name = doccoord.xpath('//name')
                        if district_name:
                            txt = district_name[0].text_content()
                            for district in self.district_list:
                                if district.title.lower() in txt.lower():
                                    advert.district = district
                                    logger.info('получен район')
                                    break
                        if not advert.district:
                            district_name = doccoord.xpath('//description')
                            if district_name:
                                txt = district_name[0].text_content()
                                for district in self.district_list:
                                    if district.title.lower() in txt.lower():
                                        advert.district = district
                                        logger.info('получен район')
                                        break
                    except Exception, err:
                        logger.info(traceback.format_exc())

                # телефон
                nodes = doc_advert.xpath('.//a[contains(@data-url, "showcontactnumbers")]')
                if nodes:
                    href = self.domain + nodes[0].get('data-url')
                    try:
                        h = {
                            'referer': nodes[0].get('href'),
                            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/39.0.2171.65 Chrome/39.0.2171.65 Safari/537.36',
                            'x-requested-with': 'XMLHttpRequest',
                        }
                        r = requests.post(href, cookies=self.cookies, headers=h)
                        need_wait = True
                        if r.status_code == 200:
                            text = r.text
                            m = re.findall(u'#(\d+)#', text, re.UNICODE)
                            if m:
                                txt = m[0]
                                if txt.startswith('8'):
                                    txt = '7' + txt[1:]
                                owner_tel = clear_tel(txt)
                                logger.info(u'открыл телефон %s' % owner_tel)
                                advert.owner_tel = owner_tel
                                result = advert.check_spam(actions=True, level=level)
                                if result:
                                    logger.info(result)
                    except Exception,  err:
                        logger.info(traceback.format_exc())
                else:
                    logger.info('кнопка телефона не найдена')

                if not advert.owner_tel:
                    logger.info('телефон не найден')
                    continue

                advert.save()

                try:
                    elems = doc_advert.xpath('//div[@class="fotorama"]/a')
                    if elems:
                        logger.info('найдено %s фоток' % len(elems))
                        for a in elems:
                            try:
                                src = a.get('href')
                                logger.info(src)
                                image = UserImage(user=advert.user)
                                if image.load_image_domofond_crop(src):
                                    image.save()
                                    advert.images.add(image)
                            except Exception, err:
                                logger.debug(traceback.format_exc())
                except Exception, err:
                    logger.debug(traceback.format_exc())

                if advert.status == Advert.STATUS_VIEW:
                    advert.find_clients()
                advert.find_metro_distance()
                if advert.check_owner():
                    advert.save()
                logger.info(advert.id)

        return True

    def process_url(self, url, adtype, limit, need=Advert.NEED_SALE, set_moderate=True, level=Advert.CHECK_SPAM_LOW):
        r = requests.get(url, cookies=self.cookies, allow_redirects=True, headers=self.headers)
        # self.cookies = dict(r.cookies.items())
        doc = fromstring(r.text)
        doc.make_links_absolute(self.domain)
        self.process_elements(doc, adtype, limit, need, set_moderate, level)

    def collect(self):
        logger.info('#### САНКТ ПЕТЕРБУРГ ####')
        start = datetime.now()

        self.cached_ids = cache.get('parser_domofond_ids', [])
        self.cookies = cache.get('parser_domofond_cookies', {})

        self.town = Town.objects.get(id=2)
        self.metro_list = self.town.metro_set.all()
        self.district_list = self.town.district_set.all()
        self.parser = Parser.objects.get(title='domofond')
        try:
            logger.info('#### КВАРТИРЫ ####')
            self.process_url('https://www.domofond.ru/arenda-kvartiry-sankt_peterburg-c3414?NoCommission=True&RentalRate=Month&PrivateListingType=PrivateOwner',
                             adtype=Advert.TYPE_LEASE, limit=Advert.LIMIT_LONG, set_moderate=True, level=Advert.CHECK_SPAM_STRONG)
        except Exception, err:
            logger.info(traceback.format_exc())

        try:
            logger.info('#### КОМНАТЫ ####')
            self.process_url('https://www.domofond.ru/arenda-komnaty-sankt_peterburg-c3414?NoCommission=True&RentalRate=Month&PrivateListingType=PrivateOwner',
                             adtype=Advert.TYPE_LEASE, limit=Advert.LIMIT_LONG, set_moderate=True, level=Advert.CHECK_SPAM_STRONG)

        except Exception, err:
            logger.info(traceback.format_exc())
        print 'питер %s' % (datetime.now() - start).seconds
        start = datetime.now()

        logger.info('#### МОСКВА ####')
        self.town = Town.admin_objects.get(slug='moskva')
        self.metro_list = self.town.metro_set.all()
        self.district_list = self.town.district_set.all()
        try:
            logger.info('#### КВАРТИРЫ ####')
            self.process_url('https://www.domofond.ru/arenda-kvartiry-moskva-c3584?NoCommission=True&RentalRate=Month&PrivateListingType=PrivateOwner',
                             adtype=Advert.TYPE_LEASE, limit=Advert.LIMIT_LONG, set_moderate=True, level=Advert.CHECK_SPAM_STRONG)
        except Exception, err:
            logger.info(traceback.format_exc())

        try:
            logger.info('#### КОМНАТЫ ####')
            self.process_url('https://www.domofond.ru/arenda-komnaty-moskva-c3584?NoCommission=True&RentalRate=Month&PrivateListingType=PrivateOwner',
                             adtype=Advert.TYPE_LEASE, limit=Advert.LIMIT_LONG, set_moderate=True, level=Advert.CHECK_SPAM_STRONG)
        except Exception, err:
            logger.info(traceback.format_exc())

        print 'москва %s' % (datetime.now() - start).seconds
        start = datetime.now()

        # logger.info('#### НОВОСИБИРСК ####')
        # self.town = Town.admin_objects.get(slug='novosibirsk')
        # self.metro_list = self.town.metro_set.all()
        # self.district_list = self.town.district_set.all()
        # try:
        #     logger.info('#### КВАРТИРЫ ####')
        #     self.process_url('https://m.avito.ru/novosibirsk/kvartiry/sdam/na_dlitelnyy_srok?user=1',
        #                      adtype=Advert.TYPE_LEASE, limit=Advert.LIMIT_LONG, set_moderate=False, level=Advert.CHECK_SPAM_STRONG)
        # except Exception, err:
        #     logger.info(traceback.format_exc())
        #
        # try:
        #     logger.info('#### КОМНАТЫ ####')
        #     self.process_url('https://m.avito.ru/novosibirsk/komnaty/sdam/na_dlitelnyy_srok?user=1',
        #                      adtype=Advert.TYPE_LEASE, limit=Advert.LIMIT_LONG, set_moderate=False, level=Advert.CHECK_SPAM_STRONG)
        # except Exception, err:
        #     logger.info(traceback.format_exc())
        #
        # print 'новосибирск %s' % (datetime.now() - start).seconds
        # start = datetime.now()
        #
        # logger.info('#### ЕКАТЕРИНБУРГ ####')
        # self.town = Town.admin_objects.get(slug='ekaterinburg')
        # self.metro_list = self.town.metro_set.all()
        # self.district_list = self.town.district_set.all()
        # try:
        #     logger.info('#### КВАРТИРЫ ####')
        #     self.process_url('https://m.avito.ru/ekaterinburg/kvartiry/sdam/na_dlitelnyy_srok?user=1',
        #                      adtype=Advert.TYPE_LEASE, limit=Advert.LIMIT_LONG, set_moderate=False, level=Advert.CHECK_SPAM_STRONG)
        # except Exception, err:
        #     logger.info(traceback.format_exc())
        #
        # try:
        #     logger.info('#### КОМНАТЫ ####')
        #     self.process_url('https://m.avito.ru/ekaterinburg/komnaty/sdam/na_dlitelnyy_srok?user=1',
        #                      adtype=Advert.TYPE_LEASE, limit=Advert.LIMIT_LONG, set_moderate=False, level=Advert.CHECK_SPAM_STRONG)
        # except Exception, err:
        #     logger.info(traceback.format_exc())
        #
        # print 'екатеринбург %s' % (datetime.now() - start).seconds

        if len(self.cached_ids) > 1000:
            self.cached_ids = self.cached_ids[(len(self.cached_ids) - 1000):]
        cache.set('parser_domofond_ids', self.cached_ids, 6 * 60 * 60)
        cache.set('parser_domofond_cookies', self.cookies, 84320)
        logger.info('#### ВЫХОД ####')
